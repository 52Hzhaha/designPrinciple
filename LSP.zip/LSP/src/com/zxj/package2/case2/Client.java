package com.zxj.package2.case2;

import org.junit.Test;

/**
 * 客户端
 */
public class Client {

    /**
     * 增加长方形的宽度，直至宽度大于长度
     * @param rectangle
     */
    public static void resizeWidth(Rectangle rectangle) {
        while (rectangle.getWidth() <= rectangle.getLength()){
            rectangle.setWidth(rectangle.getWidth()+1);
            System.out.println("长度：" + rectangle.getLength() + " 宽度:" + rectangle.getWidth());
        }
        System.out.println("resize方法结束，长度：" + rectangle.getLength() + " 宽度:" + rectangle.getWidth());
    }

    @Test
    public void test1(){
        Rectangle rectangle = new Rectangle();
        rectangle.setWidth(10);
        rectangle.setLength(20);
        resizeWidth(rectangle);
    }

    @Test
    public void test2(){
        Square square = new Square();
        square.setWidth(10);
        square.setLength(20);
        resizeWidth(square);
    }
}

package com.zxj.package2.case2;

/**
 * 正方形
 */
public class Square extends Rectangle {

    public void setLength(long length) {
        super.setLength(length);
        super.setWidth(length);
    }

    public void setWidth(long width) {
        super.setLength(width);
        super.setWidth(width);
    }

}

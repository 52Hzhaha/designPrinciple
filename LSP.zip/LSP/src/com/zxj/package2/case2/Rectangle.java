package com.zxj.package2.case2;

/**
 * 长方形
 */
public class Rectangle {
    public long length;// 长度
    public long width;// 宽度

    public long getLength() {
        return length;
    }

    public void setLength(long length) {
        this.length = length;
    }

    public long getWidth() {
        return width;
    }

    public void setWidth(long width) {
        this.width = width;
    }

}

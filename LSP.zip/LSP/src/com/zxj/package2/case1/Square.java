package com.zxj.package2.case1;

/**
 * 正方形
 */
public class Square extends Rectangle {

}

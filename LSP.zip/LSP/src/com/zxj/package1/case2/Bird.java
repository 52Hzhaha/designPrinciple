package com.zxj.package1.case2;

/**
 * 鸟类
 */
public class Bird extends Animal {
    public void fly(){
        System.out.println("我在飞！");
    }
}

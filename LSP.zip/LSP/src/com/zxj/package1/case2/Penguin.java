package com.zxj.package1.case2;

/**
 * 企鹅类
 */
public class Penguin extends Animal {
    public void walk(){
        System.out.println("我在行走！");
    }
}
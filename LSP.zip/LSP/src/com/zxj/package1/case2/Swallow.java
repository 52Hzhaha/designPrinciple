package com.zxj.package1.case2;

/**
 * 燕子类
 */
public class Swallow extends Bird {

}

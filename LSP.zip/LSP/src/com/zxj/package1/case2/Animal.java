package com.zxj.package1.case2;

/**
 * 动物类
 */
public class Animal {
    public void eat(){
        System.out.println("我在吃饭！");
    }

    public void sleep(){
        System.out.println("我在睡觉！");
    }
}

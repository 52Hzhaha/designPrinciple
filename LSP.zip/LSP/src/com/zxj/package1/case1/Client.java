package com.zxj.package1.case1;

/**
 * 客户端
 */
public class Client {
    public static void main(String[] args) {
        Swallow swallow = new Swallow();
        swallow.fly();

        Penguin penguin = new Penguin();
        penguin.fly();
    }
}

package com.zxj.package1.case1;

/**
 * 企鹅类
 * 子类
 */
public class Penguin extends Bird {
    @Override
    public void fly() {
        System.out.println("我不会飞啊！");
    }
}

package com.zxj.package1.case1;

/**
 * 鸟
 * 父类
 */
public class Bird {
    public void fly(){
        System.out.println("我在飞！");
    }
}

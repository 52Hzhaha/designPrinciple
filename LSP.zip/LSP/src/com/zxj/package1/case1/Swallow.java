package com.zxj.package1.case1;

/**
 * 燕子类
 * 子类
 */
public class Swallow extends Bird {

}

package com.zxj.case1.program4;

/**
 * 报警接口
 */
public interface Alarm {

    void alarm();// 报警

}

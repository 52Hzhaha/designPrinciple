package com.zxj.case1.program4;

import com.zxj.case1.program3.Door;

/**
 * 普通的门
 */
public class CommonDoor implements Door{
    @Override
    public void lock() {
        System.out.println("上锁");
    }

    @Override
    public void unlock() {
        System.out.println("开锁");
    }
}

package com.zxj.case1.program4;

/**
 * 具有报警功能的门
 * 注意：java语法规定，extends和implements同时使用时，必须
 * 把extends放在前面，implements放在后面。
 */
public class AlarmDoor extends CommonDoor implements Alarm {

    @Override
    public void lock() {
        System.out.println("上锁");
    }

    @Override
    public void unlock() {
        System.out.println("开锁");
    }

    @Override
    public void alarm() {
        System.out.println("报警");
    }
}

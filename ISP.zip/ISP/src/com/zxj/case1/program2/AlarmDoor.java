package com.zxj.case1.program2;

import com.zxj.case1.program1.Door;

/**
 * 具有报警功能的门
 */
public class AlarmDoor implements Door{

    @Override
    public void lock() {
        System.out.println("上锁");
    }

    @Override
    public void unlock() {
        System.out.println("开锁");
    }

    @Override
    public void alarm() {
        System.out.println("报警");
    }

}

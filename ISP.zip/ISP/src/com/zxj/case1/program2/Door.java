package com.zxj.case1.program2;

/**
 * 门 接口
 */
public interface Door extends Alarm{

    void lock();// 上锁
    void unlock();// 开锁

}

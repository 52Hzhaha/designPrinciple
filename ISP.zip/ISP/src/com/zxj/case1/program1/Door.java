package com.zxj.case1.program1;

/**
 * 门 接口
 */
public interface Door {

    void lock();// 上锁
    void unlock();// 开锁
    void alarm();// 报警

}

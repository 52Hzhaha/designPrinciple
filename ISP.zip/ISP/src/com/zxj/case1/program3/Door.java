package com.zxj.case1.program3;

/**
 * 门 接口
 */
public interface Door{

    void lock();// 上锁
    void unlock();// 开锁

}

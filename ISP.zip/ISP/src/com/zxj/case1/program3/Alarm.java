package com.zxj.case1.program3;

/**
 * 报警接口
 */
public interface Alarm {

    void alarm();// 报警

}

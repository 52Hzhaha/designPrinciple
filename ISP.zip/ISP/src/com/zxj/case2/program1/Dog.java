package com.zxj.case2.program1;

/**
 * 具体的动物：狗
 */
public class Dog implements Animal{
    @Override
    public void eat() {
        System.out.println("小狗在吃饭");
    }

    /**
     * 小狗在飞，肯定是不对的，但是Dog实现Animal接口，fly方法就必须实现，
     * 哪怕是一个空实现，违反接口隔离原则
     */
    @Override
    public void fly() {

    }

    @Override
    public void swim() {
        System.out.println("小狗在游泳");
    }
}

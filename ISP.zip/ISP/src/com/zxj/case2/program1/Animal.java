package com.zxj.case2.program1;

/**
 * 动物 接口
 */
public interface Animal {
    void eat();// 吃
    void fly();// 飞
    void swim();// 游泳
}

package com.zxj.case2.program1;

/**
 * 具体的动物 鸟
 */
public class Bird implements Animal {
    @Override
    public void eat() {
        System.out.println("小鸟在吃饭");
    }

    @Override
    public void fly() {
        System.out.println("小鸟在飞");
    }

    /**
     * 小鸟在游泳，肯定是不对的，但是Bird实现Animal接口，swim方法就必须实现，
     * 哪怕是一个空实现，违反接口隔离原则
     */
    @Override
    public void swim() {

    }
}

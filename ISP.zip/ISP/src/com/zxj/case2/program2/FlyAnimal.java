package com.zxj.case2.program2;

/**
 * 会飞的动物 接口
 */
public interface FlyAnimal {

    void eat();
    void fly();

}

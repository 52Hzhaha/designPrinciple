package com.zxj.case2.program2;

/**
 * 具体的动物：鸟
 */
public class Bird implements FlyAnimal{
    @Override
    public void eat() {
        System.out.println("小鸟在吃饭");
    }

    @Override
    public void fly() {
        System.out.println("小鸟在飞");
    }
}

package com.zxj.case2.program2;

/**
 * 具体的动物：狗
 */
public class Dog implements SwimAnimal{

    @Override
    public void eat() {
        System.out.println("小狗在吃饭");
    }

    @Override
    public void swim() {
        System.out.println("小狗在游泳");
    }


}

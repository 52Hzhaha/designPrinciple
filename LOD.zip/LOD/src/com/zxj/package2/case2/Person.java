package com.zxj.package2.case2;


/**
 * 人
 */
public class Person {
    private Computer computer;

    /**
     * 按下计算机的关机按钮方法
     */
    public void clickCloseButton(){
        computer.close();
    }
}

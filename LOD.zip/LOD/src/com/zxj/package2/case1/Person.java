package com.zxj.package2.case1;


/**
 * 人
 */
public class Person {
    private Computer computer;

    /**
     * 按下计算机的关机按钮方法
     */
    public void clickCloseButton(){
        /**
         * 现在你要开始关闭计算机了，正常来说你只需要调用Computer的close()方法即可，
         * 但是你发现Computer所有的方法都是公开的，该怎么关闭呢？于是你写下了以下关闭的流程。
         */
        computer.saveCurrentTask();
        computer.closePower();
        computer.close();

        //亦或是以下的操作
        computer.closePower();

        //还可能是以下的操作
        computer.close();
        computer.closePower();
    }
}

package com.zxj.package2.case1;

/**
 * 计算机类
 */
public class Computer {

    public void saveCurrentTask(){
        System.out.println("保存当前未完成的任务");
    }
    public void closeService(){
        System.out.println("关闭相关的服务");
    }
    public void closeScreen(){
        System.out.println("关闭显示器");
    }
    public void closePower(){
        System.out.println("关闭电源");
    }

    /**
     * 关机方法
     */
    public void close(){
        saveCurrentTask();
        closeService();
        closeScreen();
        closePower();
    }

}

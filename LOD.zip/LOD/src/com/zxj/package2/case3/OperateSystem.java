package com.zxj.package2.case3;

/**
 * 计算机操作系统
 */
public class OperateSystem {

    private void saveCurrentTask(){
        System.out.println("保存当前未完成的任务");
    }
    private void closeService(){
        System.out.println("关闭相关的服务");
    }
    private void closeScreen(){
        System.out.println("关闭显示器");
    }
    private void closePower(){
        System.out.println("关闭电源");
    }

    /**
     * 关机方法
     */
    public void close(){
        saveCurrentTask();
        closeService();
        closeScreen();
        closePower();
    }

}

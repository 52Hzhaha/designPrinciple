package com.zxj.package2.case3;

/**
 * 计算机相关硬件
 */
public class Hardware {

    private OperateSystem operateSystem;

    public void sendCloseCommand(){
        operateSystem.close();
    }
}

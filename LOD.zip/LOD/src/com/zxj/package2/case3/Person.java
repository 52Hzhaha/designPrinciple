package com.zxj.package2.case3;


/**
 * 人
 */
public class Person {
    private Hardware hardware;

    /**
     * 按下计算机的关机按钮方法
     */
    public void clickCloseButton(){
        hardware.sendCloseCommand();
    }
}

package com.zxj.package1;

/**
 * 被依赖的类
 */
public class B {

}

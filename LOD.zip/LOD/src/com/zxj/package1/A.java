package com.zxj.package1;

/**
 * A类依赖B类
 */
public class A {
    /**
     * B类作为A类的成员变量，二者是直接朋友的关系。
     */
    public B b;

    /**
     * B类作为A类的方法的参数，二者是直接朋友的关系。
     * @param b
     */
    public void test1(B b){
        System.out.println(b);
    }

    /**
     * B类作为A类的方法的返回值，二者是直接朋友的关系。
     * @return
     */
    public B test2(){
        /**
         * B类作为A类的局部变量(方法的变量)，二者不是直接朋友的关系，只是简单朋友的关系。
         */
        B b = new B();
        return b;
    }
}

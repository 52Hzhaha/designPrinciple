package com.zxj.example1.program2;

/**
 * 将字符写入打印机
 */
public class WritePrinter {
    public void write(char c){
        System.out.println("将字符写入打印机");
    }
}

package com.zxj.example1.program2;

/**
 * 从键盘读取字符
 */
public class ReadKeyboard {
    public char read(){
        char c = 'k';// 'k'是从键盘读取到的字符;
        System.out.println("从键盘读取字符");
        return c;
    }
}

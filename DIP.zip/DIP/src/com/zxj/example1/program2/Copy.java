package com.zxj.example1.program2;

import static sun.nio.ch.IOStatus.EOF;

public class Copy {
    ReadKeyboard rdKbd = new ReadKeyboard();// 从键盘读取字符
    WritePrinter wrtPrt = new WritePrinter();// 将字符写入打印机
    ReadPapertape rdPt = new ReadPapertape();// 从纸带读入机读取字符

    /**
     * copy方法增加一个boolean类型的入参ptFlag，来对输入字符的设备做判断。
     * 当ptFlag为true的时候，表示从键盘读取字符，为false的时候，表示从纸带读入机读取字符。
     * @param ptFlag
     */
    public void copy(boolean ptFlag){
        char c;
        while(( c = ptFlag ? rdKbd.read() : rdPt.read()) != EOF){
            wrtPrt.write(c);
        }
    }
}

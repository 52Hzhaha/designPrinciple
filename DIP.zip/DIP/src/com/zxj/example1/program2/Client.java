package com.zxj.example1.program2;

/**
 * 客户端
 */
public class Client {
    public static void main(String[] args) {
        Copy copy = new Copy();
        copy.copy(false);// 参数传false，表示希望从纸带读入机读取字符
    }
}

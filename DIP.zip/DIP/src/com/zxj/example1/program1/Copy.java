package com.zxj.example1.program1;

import static sun.nio.ch.IOStatus.EOF;

/**
 * 主程序
 */
public class Copy {
    ReadKeyboard rdKbd = new ReadKeyboard();// 从键盘读取字符
    WritePrinter wrtPrt = new WritePrinter();// 将字符写入打印机
    public void copy(){
        char c;
        while((c = rdKbd.read()) != EOF){
            wrtPrt.write(c);
        }
    }
}

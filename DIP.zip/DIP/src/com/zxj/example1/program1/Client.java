package com.zxj.example1.program1;

/**
 * 客户端
 */
public class Client {
    public static void main(String[] args) {
        Copy copy = new Copy();
        copy.copy();
    }
}
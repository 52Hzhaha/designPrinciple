package com.zxj.example1.program3;

/**
 * 从纸带读入机读取字符
 */
public class ReadPapertape {
    public char read(){
        char c = 'p';// 'p'是从纸带读入机读取到的字符
        System.out.println("从带读入机读取字符");
        return c;
    }
}

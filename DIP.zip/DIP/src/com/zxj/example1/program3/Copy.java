package com.zxj.example1.program3;

import static sun.nio.ch.IOStatus.EOF;

public class Copy {
    ReadKeyboard rdKbd = new ReadKeyboard();// 从键盘读取字符
    WritePrinter wrtPrt = new WritePrinter();// 将字符写入打印机
    ReadPapertape rdPt = new ReadPapertape();// 从纸带读入机读取字符
    WriteTapepuncher wrtTpc = new WriteTapepuncher();// 将字符写入纸带穿孔机

    /**
     * copy方法再增加一个boolean类型的入参punchFlag，来对输出字符的设备做判断。
     * 当punchFlag为true的时候，表示将字符写入打印机，为false的时候，表示从纸带读入机读取信将字符写入纸带穿孔机。
     * @param ptFlag
     */
    public void copy(boolean ptFlag, boolean punchFlag){
        char c;
        while(( c = ptFlag ? rdKbd.read() : rdPt.read()) != EOF){
            if (punchFlag) {
                wrtTpc.write(c);
            } else {
                wrtPrt.write(c);
            }
        }
    }
}

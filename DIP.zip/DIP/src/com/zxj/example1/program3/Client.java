package com.zxj.example1.program3;

/**
 * 客户端
 */
public class Client {
    public static void main(String[] args) {
        Copy copy = new Copy();
        /**
         * 第一个参数传true，表示从键盘读取字符，
         * 第二个参数传false,表示将字符写入到纸带穿孔机。
         */
        copy.copy(true,false);
    }
}

package com.zxj.example1.program3;

/**
 * 将读取到的字符写入纸带穿孔机
 */
public class WriteTapepuncher {
    public void write(char c){
        System.out.println("将字符写入纸带穿孔机");
    }
}

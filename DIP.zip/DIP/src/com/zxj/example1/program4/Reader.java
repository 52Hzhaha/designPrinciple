package com.zxj.example1.program4;

/**
 * 输入设备抽象
 */
public interface Reader {

    char read();

}

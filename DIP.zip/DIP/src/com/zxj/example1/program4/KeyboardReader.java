package com.zxj.example1.program4;

/**
 * 输入设备是键盘
 */
public class KeyboardReader implements Reader{
    public char read(){
        char c = 'k';// 'k'是从键盘读取到的字符;
        System.out.println("从键盘读取字符");
        return c;
    }
}

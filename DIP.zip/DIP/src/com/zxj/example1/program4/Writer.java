package com.zxj.example1.program4;

/**
 * 输出设备抽象
 */
public interface Writer {

    void write(char c);

}

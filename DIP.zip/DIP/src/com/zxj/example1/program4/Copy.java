package com.zxj.example1.program4;

import static sun.nio.ch.IOStatus.EOF;

/**
 * 主程序
 */
public class Copy {
    public void copy(Reader reader, Writer writer){
        char c;
        while((c = reader.read()) != EOF){
            writer.write(c);
        }
    }
}


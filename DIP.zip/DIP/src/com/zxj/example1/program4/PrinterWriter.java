package com.zxj.example1.program4;

/**
 * 输出设备是打印机
 */
public class PrinterWriter implements Writer{
    public void write(char c){
        System.out.println("将字符写入打印机");
    }
}

package com.zxj.example1.program4;


/**
 * 客户端
 */
public class Client {
    public static void main(String[] args) {
        Copy copy = new Copy();
        // 我们希望从键盘读取字符，将字符输入到打印机中
        copy.copy(new KeyboardReader(),new PrinterWriter());
    }
}
